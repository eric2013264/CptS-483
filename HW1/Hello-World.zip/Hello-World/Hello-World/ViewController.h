//
//  ViewController.h
//  Hello-World
//
//  Created by Eric Chen on 1/14/16.
//  Copyright © 2016 WSU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)hideImageButtonPressed:(UIButton *)sender;

@property (weak, nonatomic) IBOutlet UIButton *hideImageButton;

@property (weak, nonatomic) IBOutlet UIImageView *myImage;

@property (strong, nonatomic) IBOutlet UITapGestureRecognizer *touchedit;

@end

